﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System_biuro_podróży;



namespace System_biuro_podróży
{
    public abstract class WycieczkaBase : ICloneable
    {
        public string Id { get; set; }
        public string MiejsceDocelowe { get; set; }
        public decimal Cena { get; set; }
        public DateTime DataRozpoczecia { get; set; }
        public DateTime DataZakonczenia { get; set; }
        public string ProgramWycieczki { get; set; }

        public WycieczkaBase() // Dodaj konstruktor bezparametrowy
        {
            // Konstruktor bezparametrowy
        }

        public WycieczkaBase(string id, string miejsceDocelowe, decimal cena, DateTime dataRozpoczecia, DateTime dataZakonczenia, string program)
        {
            Id = id;
            MiejsceDocelowe = miejsceDocelowe;
            Cena = cena;
            DataRozpoczecia = dataRozpoczecia;
            DataZakonczenia = dataZakonczenia;
            ProgramWycieczki = program;
        }

        // Metoda do aktualizacji danych wycieczki
        public void AktualizujWycieczke(string noweMiejsceDocelowe, decimal nowaCena, DateTime nowaDataRozpoczecia, DateTime nowaDataZakonczenia, string nowyProgram)
        {
            MiejsceDocelowe = noweMiejsceDocelowe;
            Cena = nowaCena;
            DataRozpoczecia = nowaDataRozpoczecia;
            DataZakonczenia = nowaDataZakonczenia;
            ProgramWycieczki = nowyProgram;
        }
        // Implementacja metody ToString() w klasie
        public override string ToString()
        {
            return $"ID: {Id}, Cel: {MiejsceDocelowe}, Cena: {Cena}, Data Rozpoczęcia: {DataRozpoczecia.ToShortDateString()}, Data Zakończenia: {DataZakonczenia.ToShortDateString()}, Program: {ProgramWycieczki}";
        }

        public interface IZarzadzanieWycieczkami
        {
            void DodajWycieczke(Wycieczka wycieczka);
            Wycieczka ZnajdzWycieczke(string id);
            void AktualizujWycieczke(string id, string noweMiejsceDocelowe, decimal nowaCena);
            void UsunWycieczke(string id);
            void WyswietlWycieczki();
        }

        // Implementacja interfejsu ICloneable
        public object Clone()
        {
            return MemberwiseClone();
        }
    }

}

