﻿using System.Xml.Serialization;
using System_biuro_podróży;


class Program
{
    // Utworzenie klasy potomnej, która dziedziczy z WycieczkaBase i używanie jej do tworzenia instancji
    public class KonkretnaWycieczka : WycieczkaBase
    {
        // Konstruktor klasy potomnej, który wywołuje konstruktor klasy bazowej
        public KonkretnaWycieczka(string id, string miejsceDocelowe, decimal cena, DateTime dataRozpoczecia, DateTime dataZakonczenia, string program)
            : base(id, miejsceDocelowe, cena, dataRozpoczecia, dataZakonczenia, program)
        {
        }
    }
        static void TestWycieczkiBase()
    {
        // Utworzenie przykładowych wycieczek
        KonkretnaWycieczka wycieczka1 = new KonkretnaWycieczka("1", "Paryż", 1000m, DateTime.Now, DateTime.Now.AddDays(7), "Zwiedzanie");
        KonkretnaWycieczka wycieczka2 = new KonkretnaWycieczka("2", "Rzym", 1200m, DateTime.Now.AddDays(1), DateTime.Now.AddDays(8), "Wypoczynek");

        // Wyświetlenie szczegółów wycieczek
        Console.WriteLine(wycieczka1);
        Console.WriteLine(wycieczka2);

        // Aktualizacja szczegółów wycieczki
        wycieczka1.AktualizujWycieczke("Madryt", 1100m, DateTime.Now, DateTime.Now.AddDays(10), "Odkrywanie Miasta");
        Console.WriteLine("Po aktualizacji:");
        Console.WriteLine(wycieczka1);

        // Testowanie porównania wycieczek
        Console.WriteLine("Czy wycieczka1 jest równa wycieczka2: " + wycieczka1.Equals(wycieczka2));
    }
    static void TestKlienta()
    {
        // Utworzenie nowego klienta
        Klient klient = new Klient("1", "Jan", "Kowalski", "jan.kowalski@example.com", "123456789");

        // Wyświetlenie danych klienta przed aktualizacją
        Console.WriteLine("Dane klienta przed aktualizacją:");
        Console.WriteLine($"Id: {klient.Id}, Imię: {klient.Imie}, Nazwisko: {klient.Nazwisko}, Email: {klient.Email}, Numer Telefonu: {klient.NumerTelefonu}");

        // Aktualizacja danych kontaktowych klienta
        klient.AktualizujDaneKontaktowe("jan.nowakowski@example.com", "987654321");

        // Wyświetlenie danych klienta po aktualizacji
        Console.WriteLine("Dane klienta po aktualizacji:");
        Console.WriteLine($"Id: {klient.Id}, Imię: {klient.Imie}, Nazwisko: {klient.Nazwisko}, Email: {klient.Email}, Numer Telefonu: {klient.NumerTelefonu}");
    }
    static void TestBiuroPodrozy()
    {
        // Instancja BiuroPodrozy
        BiuroPodrozy biuro = new BiuroPodrozy();
        // Dodanie klientów
        biuro.DodajKlienta(new Klient("1", "Jan", "Kowalski", "jan@example.com", "123456789"));
        biuro.DodajKlienta(new Klient("2", "Anna", "Nowak", "anna@example.com", "987654321"));

        // Wyświetlenie listy klientów
        Console.WriteLine("Lista klientów:");
        biuro.WyswietlKlientow();

        // Aktualizacja danych klienta
        biuro.AktualizujKlienta("1", "Janek", "Nowakowski");

        // Usunięcie klienta
        biuro.UsunKlienta("2");

        // Wyświetlenie listy klientów po aktualizacji i usunięciu
        Console.WriteLine("Lista klientów po aktualizacji i usunięciu:");
        biuro.WyswietlKlientow();

        // Dodanie wycieczek
        biuro.DodajWycieczke(new Wycieczka("1", "Paryż", 2500.00m, DateTime.Now, DateTime.Now.AddDays(7), 5));
        biuro.DodajWycieczke(new Wycieczka("2", "Rzym", 3000.00m, DateTime.Now.AddDays(1), DateTime.Now.AddDays(8), 7));

        // Wyświetlenie listy wycieczek
        Console.WriteLine("Lista wycieczek:");
        biuro.WyswietlWycieczki();

        // Aktualizacja danych wycieczki
        biuro.AktualizujWycieczke("1", "Londyn", 3500.00m);

        // Usunięcie wycieczki
        biuro.UsunWycieczke("2");

        // Wyświetlenie listy wycieczek po aktualizacji i usunięciu
        Console.WriteLine("Lista wycieczek po aktualizacji i usunięciu:");
        biuro.WyswietlWycieczki();
    }
        static void TestPrzewodnika()
    {
        // Instancja BiuroPodrozy
        BiuroPodrozy biuroPodrozy = new BiuroPodrozy();

        // Dodanie kilku przewodników
        Przewodnik przewodnik1 = new Przewodnik("1", "Jan", "Kowalski", "123456789", "Historia");
        Przewodnik przewodnik2 = new Przewodnik("2", "Anna", "Nowak", "987654321", "Sztuka");

        biuroPodrozy.DodajPrzewodnika(przewodnik1);
        biuroPodrozy.DodajPrzewodnika(przewodnik2);

        // Wyświetlanie listy przewodników przed aktualizacją
        Console.WriteLine("Lista przewodników przed aktualizacją:");
        biuroPodrozy.WyswietlPrzewodnikow();
        Console.WriteLine();

        // Aktualizacja danych przewodnika
        biuroPodrozy.AktualizujPrzewodnika("1", "111222333", "Historia Sztuki");

        // Wyświetlanie zaktualizowanej listy przewodników
        Console.WriteLine("Lista przewodników po aktualizacji:");
        biuroPodrozy.WyswietlPrzewodnikow();
        Console.WriteLine();

        // Usuwanie przewodnika
        biuroPodrozy.UsunPrzewodnika("2");

        // Wyświetlanie listy przewodników po usunięciu
        Console.WriteLine("Lista przewodników po usunięciu:");
        biuroPodrozy.WyswietlPrzewodnikow();
        Console.WriteLine();

        // Dodanie klienta
        Klient klient1 = new Klient("1", "Adam", "Nowak", "adam@example.com", "555-1234");
        biuroPodrozy.DodajKlienta(klient1);

        // Wybór przewodnika przez klienta
        biuroPodrozy.WybierzPrzewodnika("1", "1");
    }
    static void TestRezerwacji()
    {
        // Tworzymy biuro podróży
        BiuroPodrozy biuroPodrozy = new BiuroPodrozy();

        // Dodajemy kilku klientów
        Klient klient1 = new Klient("1", "Jan", "Kowalski", "jan.kowalski@email.com", "123456789");
        Klient klient2 = new Klient("2", "Anna", "Nowak", "anna.nowak@email.com", "987654321");

        biuroPodrozy.DodajKlienta(klient1);
        biuroPodrozy.DodajKlienta(klient2);

        // Dodajemy kilka wycieczek
        Wycieczka wycieczka1 = new Wycieczka("1", "Paryż", 1000, DateTime.Now, DateTime.Now.AddDays(7), "Zwiedzanie", 20);
        Wycieczka wycieczka2 = new Wycieczka("2", "Rzym", 1200, DateTime.Now, DateTime.Now.AddDays(10), "Zabytki", 25);

        biuroPodrozy.DodajWycieczke(wycieczka1);
        biuroPodrozy.DodajWycieczke(wycieczka2);

        // Zarezerwuj wycieczki dla klientów i obsługa wyjątków
        try
        {
            biuroPodrozy.ZarezerwujWycieczke(klient1, "1");
            Console.WriteLine("Wycieczka zarezerwowana pomyślnie!");
        }
        catch (BrakMiejscException ex)
        {
            Console.WriteLine($"Błąd rezerwacji: {ex.Message}");
        }

        try
        {
            biuroPodrozy.ZarezerwujWycieczke(klient2, "2");
            Console.WriteLine("Wycieczka zarezerwowana pomyślnie!");
        }
        catch (BrakMiejscException ex)
        {
            Console.WriteLine($"Błąd rezerwacji: {ex.Message}");
        }

        // Wyświetl listę rezerwacji
        biuroPodrozy.WyswietlRezerwacje();

        // Anuluj rezerwację
        biuroPodrozy.AnulujRezerwacje(klient1, "1");

        // Wyświetl ponownie listę rezerwacji
        biuroPodrozy.WyswietlRezerwacje();

        Console.WriteLine("Serializacja:");
        // Zapisujemy do pliku
        biuroPodrozy.ZapiszDoPliku("biuroPodrozy.xml");

        // Wczytujemy z pliku
        BiuroPodrozy wczytaneBiuro = BiuroPodrozy.WczytajZPliku("biuroPodrozy.xml");

        // Wyświetlamy wczytane dane
        wczytaneBiuro.WyswietlKlientow();
        wczytaneBiuro.WyswietlWycieczki();
        wczytaneBiuro.WyswietlRezerwacje();

    }

    static void Klonowanie()
    {
        // Tworzymy instancję BiuroPodrozy
        BiuroPodrozy biuroPodrozy = new BiuroPodrozy();

        // Dodajemy przykładowego klienta
        Klient klient = new Klient("1", "Jan", "Kowalski", "jan@example.com", "123456789");
        biuroPodrozy.DodajKlienta(klient);

        // Dodajemy przykładową wycieczkę
        Wycieczka wycieczka = new Wycieczka("1", "Paryż", 1000, DateTime.Now, DateTime.Now.AddDays(7), 20);
        biuroPodrozy.DodajWycieczke(wycieczka);

        // Dodajemy przykładowego przewodnika
        Przewodnik przewodnik = new Przewodnik("1", "Anna", "Nowak", "987654321", "Historia sztuki");
        biuroPodrozy.DodajPrzewodnika(przewodnik);

        // Zapisujemy obiekt do pliku XML
        biuroPodrozy.ZapiszDoPliku("biuroPodrozy.xml");

        // Wczytujemy obiekt z pliku XML
        BiuroPodrozy clonedBiuroPodrozy = BiuroPodrozy.WczytajZPliku("biuroPodrozy.xml");

        // Porównujemy oryginalny obiekt z klonem
        Console.WriteLine("Oryginalny obiekt:");
        biuroPodrozy.WyswietlKlientow();
        biuroPodrozy.WyswietlWycieczki();
        biuroPodrozy.WyswietlPrzewodnikow();

        Console.WriteLine("\nKlon obiektu:");
        clonedBiuroPodrozy.WyswietlKlientow();
        clonedBiuroPodrozy.WyswietlWycieczki();
        clonedBiuroPodrozy.WyswietlPrzewodnikow();
    }

    static void Sortowanie()
    {
        // Tworzenie instancji BiuroPodrozy
        BiuroPodrozy biuroPodrozy = new BiuroPodrozy();

        // Dodanie przykładowych wycieczek
        biuroPodrozy.DodajWycieczke(new Wycieczka("1", "Paryż", 1000, DateTime.Now, DateTime.Now.AddDays(7), 20));
        biuroPodrozy.DodajWycieczke(new Wycieczka("2", "Rzym", 1200, DateTime.Now, DateTime.Now.AddDays(10), 15));
        biuroPodrozy.DodajWycieczke(new Wycieczka("3", "Barcelona", 800, DateTime.Now, DateTime.Now.AddDays(5), 25));
        biuroPodrozy.DodajWycieczke(new Wycieczka("4", "Londyn", 1500, DateTime.Now, DateTime.Now.AddDays(8), 18));
        biuroPodrozy.DodajWycieczke(new Wycieczka("5", "Berlin", 900, DateTime.Now, DateTime.Now.AddDays(6), 22));

        // Wyświetlanie wycieczek przed sortowaniem
        Console.WriteLine("Wycieczki przed sortowaniem:");
        biuroPodrozy.WyswietlWycieczki();

        // Sortowanie wycieczek po cenie rosnąco
        biuroPodrozy.wycieczki.Sort();

        // Wyświetlanie wycieczek po sortowaniu
        Console.WriteLine("\nWycieczki po sortowaniu:");
        biuroPodrozy.WyswietlWycieczki();
    }

    static void PorownywanieDanych()
    {
        // Instancja BiuroPodrozy
        BiuroPodrozy biuroPodrozy = new BiuroPodrozy();

        // Dodanie przykładowych wycieczek
        Wycieczka w1 = new Wycieczka("1", "Paryż", 1000, DateTime.Now, DateTime.Now.AddDays(7), 20);
        Wycieczka w2 = new Wycieczka("2", "Rzym", 1200, DateTime.Now, DateTime.Now.AddDays(10), 15);
        Wycieczka w3 = new Wycieczka("3", "Paryż", 800, DateTime.Now, DateTime.Now.AddDays(5), 25);
        Wycieczka w4 = new Wycieczka("4", "Londyn", 1500, DateTime.Now, DateTime.Now.AddDays(8), 18);
        Wycieczka w5 = new Wycieczka("5", "Berlin", 900, DateTime.Now, DateTime.Now.AddDays(6), 22);

        biuroPodrozy.DodajWycieczke(w1);
        biuroPodrozy.DodajWycieczke(w2);
        biuroPodrozy.DodajWycieczke(w3);
        biuroPodrozy.DodajWycieczke(w4);
        biuroPodrozy.DodajWycieczke(w5);

        biuroPodrozy.WyswietlWycieczki();

        // Porównanie wycieczek po miejscu docelowym
        Console.WriteLine($"Czy wycieczka {w1.MiejsceDocelowe} jest równa wycieczce {w2.MiejsceDocelowe}: {w1.Equals(w2)}");
        Console.WriteLine($"Czy wycieczka {w1.MiejsceDocelowe} jest równa wycieczce {w1.MiejsceDocelowe}: {w1.Equals(w1)}");
        Console.WriteLine($"Czy wycieczka {w4.MiejsceDocelowe} jest równa wycieczce {w5.MiejsceDocelowe}: {w4.Equals(w5)}");

    }
   
    static void Main(string[] args)
    {
        //TestWycieczkiBase();
        //TestKlienta();
        //TestBiuroPodrozy();
        //TestPrzewodnika();
        //TestRezerwacji();
        //Klonowanie();
        //Sortowanie();
        PorownywanieDanych();
    }
}
